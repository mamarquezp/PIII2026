const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config();

const Tarea = require('./models/Tarea.js')

const app = express();

app.use(express.json());

//conectar DB
mongoose.connect(process.env.MONGODB_URI)
.then (() => console.log('Conexión exitosa'))
.catch(err => console.error('Error',err));

// GET tareas
app.get('/tareas', async (req, res) => {
    const tareas = await Tarea.find().sort('-createdAt');
    res.json(tareas);
});

// POST 
app.post('/tareas', async (req, res) => {
    try {
        const { titulo, descripcion, prioridad, fechaLimite } = req.body;
        const nuevaTarea = new Tarea({
            titulo,
            descripcion,
            prioridad,
            fechaLimite
        });
        await nuevaTarea.save();
        res.status(201).json(nuevaTarea);
    } catch (error) {
        res.status(400).json({ mensaje: 'Error al crear la tarea', error });
    }
});

app.put('/tareas/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { titulo, completada, descripcion, prioridad, fechaLimite } = req.body;
        
        const tareaActualizada = await Tarea.findByIdAndUpdate(
            id,
            { titulo, completada, descripcion, prioridad, fechaLimite },
            { new: true, runValidators: true }
        );

        if (!tareaActualizada) {
            return res.status(404).json({ mensaje: 'Tarea no encontrada' });
        }

        res.json(tareaActualizada);
    } catch (error) {
        res.status(400).json({ mensaje: 'Error al actualizar la tarea', error });
    }
});

app.listen(3000, () => console.log('Server en 3000')
);